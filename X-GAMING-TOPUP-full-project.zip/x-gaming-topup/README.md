# X GAMING TOPUP — Full starter project

## যা আছে
- আপনার দেওয়া সব Diamond, Membership, Combo, Level Up Pass এবং Like প্যাকেজ ও দাম
- UID lookup: GamesKinbo API-তে `region=BD`; Player Name `AccountInfo.AccountName` থেকে
- API key backend-এর `.env` ফাইলে থাকে, browser-এ প্রকাশ করা হয় না
- bKash/Nagad manual payment details, TrxID সহ order submission
- SQLite order storage এবং password-protected admin approve/reject panel
- WhatsApp ও Telegram যোগাযোগ

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি **manual payment verification**। bKash/Nagad-এর automatic payment gateway যুক্ত নয়।
- Admin approve করলেই শুধু আপনার রেকর্ডে status বদলাবে; Free Fire-এ diamond স্বয়ংক্রিয়ভাবে পাঠাবে না।
- Wallet চালু নেই।
- GamesKinbo API-তে API key এবং তাদের plan/rate limit লাগবে। API response BD region ফেরত না দিলে lookup আটকে যাবে।
- Public deployment-এর আগে HTTPS, শক্তিশালী secrets, নিয়মিত backup এবং hosting-এর persistent disk ব্যবহার করুন।
- Admin password বা API key কখনো HTML/JavaScript-এ বসাবেন না।

## চালানোর নিয়ম
1. কম্পিউটার/Node.js hosting-এ Node.js 20 বা তার নতুন সংস্করণ ইনস্টল করুন।
2. এই project folder-এ terminal খুলুন।
3. চালান: `npm install`
4. `.env.example` কপি করে `.env` নামে রাখুন।
5. `.env`-এ নিজের GamesKinbo API key, শক্তিশালী admin password এবং random session secret বসান।
6. চালান: `npm start`
7. ব্রাউজারে `http://localhost:3000` খুলুন।

## Android / Hosting
W3Schools Tryit-এ শুধু `index.html` চালালে backend/API key নিরাপদে কাজ করবে না। এই ZIP-টি Node.js সমর্থিত hosting-এ deploy করতে হবে। পরে hosting provider-এর নির্দেশনা অনুযায়ী environment variables সেট করবেন।

## Environment variables
`.env.example` দেখুন।
