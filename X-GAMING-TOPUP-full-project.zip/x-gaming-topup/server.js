require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const session = require("express-session");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(process.env.DB_FILE || "orders.db");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  uid TEXT NOT NULL, player_name TEXT NOT NULL,
  package_name TEXT NOT NULL, amount INTEGER NOT NULL,
  payment_method TEXT NOT NULL, sender_number TEXT NOT NULL,
  trx_id TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(rateLimit({ windowMs: 60 * 1000, limit: 60 }));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-long-random-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const packages = [
["25 Diamonds",22],["50 Diamonds",38],["100 Diamonds",75],["115 Diamonds",79],
["240 Diamonds",158],["355 Diamonds",237],["480 Diamonds",310],["505 Diamonds",336],
["610 Diamonds",400],["725 Diamonds",479],["850 Diamonds",550],["1090 Diamonds",716],
["1240 Diamonds",800],["1480 Diamonds",958],["1720 Diamonds",1116],["1850 Diamonds",1200],
["2090 Diamonds",1358],["2530 Diamonds",1610],["3140 Diamonds",2010],["3770 Diamonds",2410],
["4010 Diamonds",2560],["5060 Diamonds",3320],["10120 Diamonds",6440],
["Weekly Membership",155],["Monthly Membership",770],
["1 Weekly + 1 Monthly",950],["2 Weekly + 2 Monthly",1915],["3 Weekly + 3 Monthly",2845],
["4 Weekly + 4 Monthly",3800],["5 Weekly + 5 Monthly",4750],["10 Weekly + 10 Monthly",9500],
["Level Up Pass - Level 6",43],["Level Up Pass - Level 10",75],
["Level Up Pass - Level 15",75],["Level Up Pass - Level 20",75],
["Level Up Pass - Level 25",75],["Level Up Pass - Level 30",105],
["200 Likes - Instant Delivery",35],["400 Likes - 2 Days",65],["600 Likes - 3 Days",95],
["1400 Likes - 7 Days",215],["3000 Likes - 15 Days",435],["6000 Likes - 1 Month",825],
["12000 Likes - 2 Months",1575],["18000 Likes - 3 Months",2325],
["36000 Likes - 6 Months",4500],["73000 Likes - 1 Year",8900]
];
const packageMap = new Map(packages.map(([name, price]) => [name, price]));

app.get("/api/packages", (req, res) => res.json(packages.map(([name, price]) => ({name, price}))));

app.get("/api/player", rateLimit({ windowMs: 60 * 1000, limit: 10 }), async (req, res) => {
  const uid = String(req.query.uid || "").trim();
  if (!/^\d{6,15}$/.test(uid)) return res.status(400).json({error:"সঠিক Free Fire UID দিন।"});
  if (!process.env.GAMESKINBO_API_KEY) return res.status(503).json({error:"সার্ভারে API Key সেট করা হয়নি।"});
  try {
    const url = new URL("https://api.gameskinbo.com/ff-info/get");
    url.searchParams.set("uid", uid);
    url.searchParams.set("region", "BD");
    const response = await fetch(url, { headers: {"x-api-key": process.env.GAMESKINBO_API_KEY} });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({error:data.error || "Player খুঁজে পাওয়া যায়নি।"});
    const info = data.AccountInfo || data.accountInfo || {};
    const name = info.AccountName || info.accountName || info.nickname;
    const region = String(info.AccountRegion || info.region || "").toUpperCase();
    if (!name) return res.status(404).json({error:"এই UID-এর Player Name পাওয়া যায়নি।"});
    if (region && region !== "BD") return res.status(404).json({error:"এই UID বাংলাদেশ (BD) Region-এর নয়।"});
    res.json({uid, name, region: region || "BD"});
  } catch (e) {
    res.status(502).json({error:"Player API-তে সংযোগ করা যায়নি। পরে আবার চেষ্টা করুন।"});
  }
});

app.post("/api/orders", (req, res) => {
  const {uid, playerName, packageName, paymentMethod, senderNumber, trxId} = req.body || {};
  const amount = packageMap.get(packageName);
  if (!/^\d{6,15}$/.test(String(uid || "")) || !playerName || !amount ||
      !["bKash","Nagad"].includes(paymentMethod) ||
      !/^\d{10,15}$/.test(String(senderNumber || "").replace(/\D/g,"")) ||
      !/^[A-Za-z0-9-]{6,30}$/.test(String(trxId || "").trim())) {
    return res.status(400).json({error:"তথ্যগুলো ঠিকভাবে পূরণ করুন।"});
  }
  try {
    const result = db.prepare(`INSERT INTO orders
      (uid,player_name,package_name,amount,payment_method,sender_number,trx_id)
      VALUES (?,?,?,?,?,?,?)`).run(String(uid), String(playerName).slice(0,60), packageName,
      amount, paymentMethod, String(senderNumber).replace(/\D/g,""), String(trxId).trim().toUpperCase());
    res.json({ok:true, orderId:result.lastInsertRowid, message:"অর্ডার জমা হয়েছে। পেমেন্ট যাচাইয়ের পর অ্যাডমিন আপডেট করবে।"});
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({error:"এই TrxID আগে ব্যবহার করা হয়েছে।"});
    res.status(500).json({error:"অর্ডার জমা হয়নি। আবার চেষ্টা করুন।"});
  }
});

function adminOnly(req,res,next) {
  if (req.session && req.session.admin) return next();
  res.status(401).json({error:"প্রথমে Admin Login করুন।"});
}
app.post("/api/admin/login", (req,res) => {
  if (!process.env.ADMIN_PASSWORD) return res.status(503).json({error:"Admin password সার্ভারে সেট করা হয়নি।"});
  if (String(req.body.password || "") !== process.env.ADMIN_PASSWORD) return res.status(401).json({error:"Password সঠিক নয়।"});
  req.session.admin = true; res.json({ok:true});
});
app.post("/api/admin/logout", adminOnly, (req,res) => req.session.destroy(() => res.json({ok:true})));
app.get("/api/admin/orders", adminOnly, (req,res) => {
  res.json(db.prepare("SELECT * FROM orders ORDER BY id DESC LIMIT 300").all());
});
app.post("/api/admin/orders/:id/status", adminOnly, (req,res) => {
  const status = req.body.status;
  if (!["approved","rejected","pending"].includes(status)) return res.status(400).json({error:"Invalid status"});
  const result = db.prepare("UPDATE orders SET status=? WHERE id=?").run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({error:"অর্ডার পাওয়া যায়নি।"});
  res.json({ok:true});
});

app.listen(PORT, () => console.log(`X GAMING TOPUP running on port ${PORT}`));
